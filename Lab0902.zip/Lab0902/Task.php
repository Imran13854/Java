<html>
	<body bgcolor="lightgray">
		<span style="color:red;">*</span>
		<span style="color:black;"> - Denotes Required Information</span>
		<br>
		<b>> 1 Donation  </b>
		&nbsp &nbsp > 2 Confirmation &nbsp &nbsp > 3 Thank You!
		<br>
		<span style="color:red;"><h2>Donor Information</h2></span>
		<br>
		<form action="SubmittedForm.php" method="post">
			<center>
				<table>
					<tr>
						<td align="right" >
							<span style="color:black;"><b>First Name</b></span>
							<span style="color:red;"><b>*</b></span>
						</td>
						<td>
							<input type="text" name="fname">
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>Last Name</b></span>
							<span style="color:red;"><b>*</b></span>
						</td>
						<td>
							<input type="text" name="lname">
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>Company</b></span>
						</td>
						<td>
							<input type="text" name="company">
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>Address 1</b></span>
							<span style="color:red;"><b>*</b></span>
						</td>
						<td>
							<input type="text" name="address1">
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>Address 2</b></span>
						</td>
						<td>
							<input type="text" name="address2">
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>City</b></span>
							<span style="color:red;"><b>*</b></span>
						</td>
						<td>
							<input type="text" name="city">
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>State</b></span>
							<span style="color:red;"><b>*</b></span>
						</td>
						<td>
							<select name="state">
								<option selected = "true">Select a State</option>
								<option>State 1</option>
								<option>State 2</option>
								<option>State 3</option>
							</select>
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>Zip Code</b></span>
							<span style="color:red;"><b>*</b></span>
						</td>
						<td>
							<input type="text" name="zipcode">
						</td>
					</tr>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>Country</b></span>
							<span style="color:red;"><b>*</b></span>
						</td>
						<td>
							<select style="width:350px;" name="country">
								<option selected = "true">Select a Country</option>
								<option>Country 1</option>
								<option>Country 2</option>
								<option>Country 3</option>
							</select>
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>Phone</b></span>
						</td>
						<td>
							<input type="text" name="phone">
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>Fax</b></span>
						</td>
						<td>
							<input type="text" name="fax">
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>Email</b></span>
							<span style="color:red;"><b>*</b></span>
						</td>
						<td>
							<input type="text" name="email">
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>Donation Ammount</b></span>
							<span style="color:red;"><b>*</b></span>
							<br>
							<span style="black;">(Check a button or type in your</span>
							<br>
							<span style="black;">ammount)</span></span>
						</td>
						<td>
							<input type="radio" name="ammount" checked = "true" "> None 
							<input type="radio" name="ammount" value="$50 "> $50 
							<input type="radio" name="ammount" value="$75"> $75
							<input type="radio" name="ammount" value="$100"> $100
							<input type="radio" name="ammount" value="$250"> $250
							<input type="radio" name="ammount" value="Other"> Other
							<br>
							<span style="color:black;"><b>Other Ammount $</b></span>
							<input type="text" name="ammountT">
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>Recurring Information</b></span>
							<br>
							<span style="black;">(Check if yes)</span>
						</td>
						<td>
							<input type="checkbox" name="agreement"> I am interested in giving on regular besis.
							<br>
							<span style="color:black;">Monthly Credit Card $</span>
							<input type="text" maxlength="4" size="4" name="credit1">
							<span style="color:black;">For</span>
							<input type="text" maxlength="3" size="3" name="credit2">
							<span style="color:black;">Months</span>	
						</td>
					</tr>
				</table>
			</center>
			<span style="color:red;"><h2>Honorarium and Memorial Donation Information</h2></span>
			<center>
				<table>
					<tr>
						<td align="right">
							<span style="color:black;"><b>I would like to make this</b></span>
							<br>
							<span style="color:black;"><b>Donation</b></span>
							<br>
						</td>
						<td>
							<input type="radio" name="honor" value="To Honor"> To Honor 
							<br>
							<input type="radio" name="honor" value="In Memory of"> In Memory of 
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>Name</b></span>
						</td>
						<td>
							<input type="text" name="dname">
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>Acknowledge Donation to</b></span>
						</td>
						<td>
							<input type="text" name="adt">
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>Address</b></span>
						</td>
						<td>
							<input type="text" name="daddress">
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>State</b></span>
						</td>
						<td>
							<select name="dstate">
								<option selected = "true">Select a State</option>
								<option>State 1</option>
								<option>State 2</option>
								<option>State 3</option>
							</select>
						</td>
					</tr>
					<tr>
						<td align="right">
							<span style="color:black;"><b>Zip</b></span>
						</td>
						<td>
							<input type="text" name="dzipcode">
						</td>
					</tr>
				</table>
			</center>
			<span style="color:red;"><h2>Additional Information</h2></span>
			<span style="color:black;">Please enter name, company or organization as you would like it to appear in our publication:</span>
			<center>
				<table>
					<tr>
						<td>
							<span><b>Name</b></span>
						</td>
						<td>
							<input type="text" name="dcompany">
						</td>
					</tr>
				</table>	
			</center>
			<input type="checkbox" name="checking[]"> I would like my gift to remain anonymous. <br>
			<input type="checkbox" name="checking[]"> My employer offers a matching gift program. I will mail the matching gift form. <br>
			<input type="checkbox" name="checking[]"> Please save the cost of acknowledging this gift by not mailing a thnak you letter. <br>
			<center>
				<table>
					<tr>
						<td valign="top">
							<span><b>Comments</b></span>
							<br>
							<span>(Please type any questions or feedback </span>
							<br>
							<span>here)</span>
						</td>
						<td>
							<!--<input type="text" style="width:300px; height:100px;">-->
							<textarea style="width:300px; height:100px;" name="tarea"></textarea>
						</td>
					</tr>
					<tr>
						<td valign="top">
							<span><b>How may we contact you?</b></span>
						</td>
						<td>
							<input type="checkbox" name="contract[]">E-mail<br>
							<input type="checkbox" name="contract[]">Postal Mail<br>
							<input type="checkbox" name="contract[]">Telephone<br>
							<input type="checkbox" name="contact[]">Fax
						</td>
					</tr>
				</table>	
			</center>
			<span style="color:gray;">I would like to receive newsletters and information about special events by:</span>
			<center>
				<table>
					<tr>
						<td>
						</td>
						<td valign="left">
							<input type="checkbox" name="media[]">E-mail<br>
							<input type="checkbox" name="media[]">Postal Mail
						</td>
					</tr>
				</table>
			</center>
			<input type="checkbox" name="agreement2">I would like the infoemation about voluteering with the<br>
			<input type="text" size="225" name="atext"><br><br>
			<center>
				<input type="button" name="reset" value="Reset">
				&nbsp
				<input type="submit" name= "submit"value="Confirm">
			</center>
			<br>
			<span>Donate online with confidence. You are on secure server.</span>
			<br>
			<span>If you have any problems or questions, please contact</span>
			<span style="color:gray;"> support.</span>
		</form>
	</body>
</html>