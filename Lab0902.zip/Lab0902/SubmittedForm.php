<html>
	<body>
		<h1>Form Submitted</h1>
		<?php
		if(isset($_REQUEST['submit']))
		{
			$fname = $_REQUEST['fname'];
			$lname = $_REQUEST['lname'];
			$company = $_REQUEST['company'];
			$address1 = $_REQUEST['address1'];
			$address2 = $_REQUEST['address2'];
			$city = $_REQUEST['city'];
			$state = $_REQUEST['state'];
			$zipcode = $_REQUEST['zipcode'];
			$country = $_REQUEST['country'];
			$phone = $_REQUEST['phone'];
			$fax = $_REQUEST['fax'];
			$email = $_REQUEST['email'];
			$ammount = $_REQUEST['ammount'];
			$ammountT = $_REQUEST['ammountT'];
			$agreement = $_REQUEST['agreement'];
			$credit1 = $_REQUEST['credit1'];
			$credit2 = $_REQUEST['credit2'];
			$honor =  $_REQUEST['honor'];
			$dname = $_REQUEST['dname'];
			$adt= $_REQUEST['adt'];
			$daddress= $_REQUEST['daddress'];
			$dstate= $_REQUEST['dstate'];
			$dzipcode= $_REQUEST['dzipcode'];
			$dcompany= $_REQUEST['dcompany'];
			$checking= $_REQUEST['checking'];
			$tarea= $_REQUEST['tarea'];
			$contract= $_REQUEST['contract'];
			$media= $_REQUEST['media'];
			$agreement2 = $_REQUEST['agreement2'];
			$atext= $_REQUEST['atext'];
		
		?>
		
		
		
		
		Fisrt Name: <?php echo $fname?><br>
		Last Name: <?php echo $lname?><br>
		Company: <?php echo $company?><br>
		Address1: <?php echo $address1?><br>
		Address2: <?php echo $address2?><br>
		City: <?php echo $city?><br>
		State: <?php echo $state?><br>		
		Zip Code: <?php echo $zipcode?><br>
		Country: <?php echo $country?><br>
		Phone: <?php echo $phone?><br>
		Fax: <?php echo $fax?><br>
		Email: <?php echo $city?><br>
		Donation Ammount: <?php echo $ammount?><br>
		Other Ammount: <?php echo $ammountT?><br>
		Agreement: <?php echo "I am interested in giving on regular besis"?><br>
		Credit:<?php echo $credit1?><br>
		Credit: <?php echo $credit2?><br>
		
		This Donation: <?php echo $honor?><br>
		Donor Name: <?php echo $dname?><br>
		Acknoladgement: <?php echo $adt?><br>
		Donor Address: <?php echo $daddress?><br>
		State: <?php echo $dstate?><br>
		ZipCode: <?php echo $dzipcode?><br>
		Company: <?php echo $dcompany?><br>
		Knoledge: <ul><?php foreach($checking as $check)
				echo "<li>$check</li>";?> </ul><br>
	    Comment: <?php echo $tarea?><br>
		Contract: <ul><?php foreach($contract as $cont)
				echo "<li>$cont</li>";?> </ul><br>
		Media: <ul><?php foreach($media as $med)
				echo "<li>$med</li>";?> </ul><br>
	    Agreement: <?php "I would like the infoemation about voluteering with the"?><br>
        Agrement Text: <?php echo $atext?><br>

		
		<?php
		}?>
		
	</body>

</html>